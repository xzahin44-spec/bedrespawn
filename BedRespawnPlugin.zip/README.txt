BedRespawnPlugin

Fonction :
- Lit existant → respawn en survival
- Lit détruit → passage en spectator

Build :
1. Installer Maven
2. Dans le dossier : mvn clean package
3. Le .jar sera dans /target

Installation :
- Glisser le .jar dans /plugins de ton serveur Paper/Spigot
- Redémarrer le serveur